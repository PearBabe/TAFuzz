#ifndef LOG_H
#define LOG_H

#include "logging.h"

#endif /* LOG_H */