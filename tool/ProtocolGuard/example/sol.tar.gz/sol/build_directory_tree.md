# Build Directory Tree Structure

## 中文版本 (Chinese Version)

```
/root/projects/artefact_temp/sol/build/
├── CMakeFiles/                           # CMake 构建文件目录
│   ├── CMakeCache.txt                    # CMake 缓存配置
│   ├── cmake_install.cmake               # CMake 安装脚本
│   ├── Makefile                          # 主构建文件
│   ├── compile_commands.json             # 编译命令数据库
│   ├── sol.dir/                          # sol 项目构建目录
│   ├── sol_test.dir/                     # sol_test 项目构建目录
│   └── 3.26.5/                           # CMake 版本目录
├── cursorkleosr/                         # AI 助手工作目录
│   ├── workflow_state.md                 # 工作流状态文件
│   ├── project_config.md                 # 项目配置
│   ├── Instructions.md                   # 指令说明
│   └── task/                             # 任务目录
│       └── rule1.txt                     # MQTT ClientId 规则分析任务
├── sol                                   # MQTT 服务器主程序 (247KB)
├── sol_test                              # 测试程序 (85KB)
├── sqlite_Sol.db                         # SQLite 数据库 (496KB)
├── sol_ssa.ll                            # SSA 形式 LLVM IR (2.6MB)
├── config.toml                           # 主配置文件 (2.3KB)
├── rule_config.txt                       # 协议规则配置 (461B)
├── callgraph.dot                         # 调用图 DOT 格式 (14KB)
├── callgraph_report.txt                  # 调用图分析报告 (8.5KB)
├── function_irrelevant.txt               # 不相关函数列表 (1.4KB)
├── function_arg_summary.txt              # 函数参数摘要 (156B)
├── extracted_commands.sh                 # 提取的命令脚本 (9.3KB)
├── extracted_commands.txt                # 提取的命令列表 (8.8KB)
├── build_log.txt                         # 构建日志 (17KB)
├── sol_ssa.bc                            # SSA 形式位码 (592KB)
├── ffp.txt                               # 过滤后的误报文件 (2.8KB)
├── fp.txt                                # 误报文件 (10.0KB)
├── sol.ll                                # LLVM 汇编文件 (3.0MB)
├── sol.bc                                # LLVM 位码文件 (580KB)
└── Makefile                              # 构建规则文件 (23KB)
```

## English Version

```
/root/projects/artefact_temp/sol/build/
├── CMakeFiles/                           # CMake build files directory
│   ├── CMakeCache.txt                    # CMake cache configuration
│   ├── cmake_install.cmake               # CMake installation script
│   ├── Makefile                          # Main build file
│   ├── compile_commands.json             # Compilation commands database
│   ├── sol.dir/                          # sol project build directory
│   ├── sol_test.dir/                     # sol_test project build directory
│   └── 3.26.5/                           # CMake version directory
├── cursorkleosr/                         # AI assistant workspace
│   ├── workflow_state.md                 # Workflow state file
│   ├── project_config.md                 # Project configuration
│   ├── Instructions.md                   # Instructions documentation
│   └── task/                             # Task directory
│       └── rule1.txt                     # MQTT ClientId rule analysis task
├── sol                                   # MQTT server main program (247KB)
├── sol_test                              # Test program (85KB)
├── sqlite_Sol.db                         # SQLite database (496KB)
├── sol_ssa.ll                            # SSA form LLVM IR (2.6MB)
├── config.toml                           # Main configuration file (2.3KB)
├── rule_config.txt                       # Protocol rule configuration (461B)
├── callgraph.dot                         # Call graph DOT format (14KB)
├── callgraph_report.txt                  # Call graph analysis report (8.5KB)
├── function_irrelevant.txt               # Irrelevant functions list (1.4KB)
├── function_arg_summary.txt              # Function argument summary (156B)
├── extracted_commands.sh                 # Extracted commands script (9.3KB)
├── extracted_commands.txt                # Extracted commands list (8.8KB)
├── build_log.txt                         # Build log (17KB)
├── sol_ssa.bc                            # SSA form bitcode (592KB)
├── ffp.txt                               # Filtered false positives (2.8KB)
├── fp.txt                                # False positives file (10.0KB)
├── sol.ll                                # LLVM assembly file (3.0MB)
├── sol.bc                                # LLVM bitcode file (580KB)
└── Makefile                              # Build rules file (23KB)
```

## File Categories Summary

### 🏗️ Build System Files
- **CMakeFiles/**: CMake generated build files
- **Makefile**: Build rules and dependencies
- **compile_commands.json**: IDE support for compilation database

### 🔍 Code Analysis Files
- **LLVM IR files** (sol.bc, sol.ll, sol_ssa.bc, sol_ssa.ll): For static analysis and program transformation
- **Call graph files** (callgraph.dot, callgraph_report.txt): Function call relationship analysis
- **Program slicing files** (function_arg_summary.txt, function_irrelevant.txt): Related code identification

### 🛡️ Security Analysis Files
- **False positive analysis** (fp.txt, ffp.txt): Security warning filtering and validation
- **Database** (sqlite_Sol.db): Analysis results storage

### ⚙️ Configuration Files
- **config.toml**: Main configuration file with LLM service, database, and project settings
- **rule_config.txt**: MQTT protocol rule definitions

### 🤖 AI Assistant Files
- **cursorkleosr/**: AI code analysis and rule validation tools
- **Workflow management**: Automated code review and fixes

### 📝 Logs and Reports
- **build_log.txt**: Build process logs
- **extracted_commands**: Command extraction and analysis

### 🎯 Executables
- **sol**: MQTT server main program
- **sol_test**: Unit test program 