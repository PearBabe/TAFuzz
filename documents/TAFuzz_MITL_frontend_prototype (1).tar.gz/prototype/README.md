# TAFuzz MITL Front-end Feasibility Prototype

This prototype validates the data contracts for one bounded CoAP response:

```text
RFC sentence -> typed property IR -> C dependency graph -> selective
instrumentation -> buffered runtime events -> TAMonitor-compatible trace
```

## Compiler requirement

The prototype requires `clang-18` or `clang` on `PATH`. It deliberately has no
GCC fallback, so the feasibility result and the production plan exercise the
same compiler family. Confirm the selected compiler before running:

```bash
clang-18 --version  # or: clang --version
```

Run all tests:

```bash
python3 -m unittest discover -s prototype/tests -v
```

Run the auditable end-to-end demo:

```bash
python3 prototype/run_demo.py
```

The demo writes `property_ir.json`, `dependency_graph.json`,
`instrumentation_plan.json`, instrumented C, runtime support, `trace.csv`, and
`verdict.txt` to `prototype/out/`.

## Deliberate limits

- The RFC recognizer accepts one explicit CON/ACK bounded-response pattern and
  rejects all other sentences instead of guessing.
- `pycparser` is used only to validate the dependency and instrumentation data
  contracts. Production C/C++ analysis must use Clang LibTooling plus LLVM/SVF.
- The demo models event propositions with point semantics. Persistent state
  propositions require change events and a valuation reconstruction layer.
- The runtime buffer is single-process and fixed-size. Production uses
  per-thread SPSC buffers in shared memory, with drop counters and a separate
  consumer.
- The small reference monitor checks only the demonstrated bounded-response
  pattern. TAFuzz production continues to use TAMonitor/MightyPPL/MoniTAal.
