from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import List

from .dependencies import analyze_source
from .extractor import extract_requirement
from .instrumentation import (
    instrument_source,
    render_runtime_support,
    select_observation_points,
)
from .monitor import evaluate_bounded_response, parse_tamonitor_trace


@dataclass(frozen=True)
class DemoResult:
    artifacts: List[Path]
    verdict: str


def _write_json(path: Path, value: object) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _find_clang() -> str:
    for executable in ("clang-18", "clang"):
        compiler = shutil.which(executable)
        if compiler is not None:
            return compiler
    raise RuntimeError("the feasibility demo requires clang-18 or clang")


def run_demo(
    *,
    requirement: str,
    source_path: Path,
    output_dir: Path,
    rfc: str,
    section: str,
) -> DemoResult:
    clang = _find_clang()

    output_dir.mkdir(parents=True, exist_ok=True)
    source = source_path.read_text(encoding="utf-8")
    prop = extract_requirement(requirement, rfc=rfc, section=section)
    graph = analyze_source(source, prop, filename=str(source_path))
    plan = select_observation_points(graph, prop)
    instrumented = instrument_source(source, plan)
    runtime_support = render_runtime_support(plan)

    property_path = output_dir / "property_ir.json"
    graph_path = output_dir / "dependency_graph.json"
    plan_path = output_dir / "instrumentation_plan.json"
    instrumented_path = output_dir / "coap_instrumented.c"
    runtime_path = output_dir / "tafuzz_runtime.c"
    trace_path = output_dir / "trace.csv"
    verdict_path = output_dir / "verdict.txt"

    property_path.write_text(prop.to_json() + "\n", encoding="utf-8")
    _write_json(
        graph_path,
        {
            "nodes": sorted(graph.nodes),
            "edges": [asdict(edge) for edge in graph.edges],
            "anchors": graph.anchors,
        },
    )
    _write_json(plan_path, {"points": [asdict(point) for point in plan.points]})
    instrumented_path.write_text(instrumented, encoding="utf-8")
    runtime_path.write_text(runtime_support, encoding="utf-8")

    with tempfile.TemporaryDirectory() as tmp:
        binary = Path(tmp) / "coap_demo"
        compile_result = subprocess.run(
            [
                clang,
                "-std=c11",
                "-Wall",
                "-Wextra",
                "-Werror",
                str(instrumented_path),
                str(runtime_path),
                "-o",
                str(binary),
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        if compile_result.returncode != 0:
            raise RuntimeError(f"instrumented demo did not compile:\n{compile_result.stderr}")
        run_result = subprocess.run(
            [str(binary)], capture_output=True, text=True, check=False
        )
        if run_result.returncode != 0:
            raise RuntimeError(f"instrumented demo failed:\n{run_result.stderr}")

    trace_path.write_text(run_result.stdout, encoding="utf-8")
    trace = parse_tamonitor_trace(run_result.stdout)
    completed_at_ms = trace[-1].time_ms if trace else 0
    verdict = evaluate_bounded_response(
        trace,
        trigger="con_sent",
        response="ack_received",
        upper_bound_ms=prop.interval.upper_ms,
        completed_at_ms=completed_at_ms,
    )
    verdict_path.write_text(verdict + "\n", encoding="utf-8")

    return DemoResult(
        artifacts=[
            property_path,
            graph_path,
            plan_path,
            instrumented_path,
            runtime_path,
            trace_path,
            verdict_path,
        ],
        verdict=verdict,
    )
