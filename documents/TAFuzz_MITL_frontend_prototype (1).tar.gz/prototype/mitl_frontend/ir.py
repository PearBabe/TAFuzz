from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from typing import Dict, List


@dataclass(frozen=True)
class TimeInterval:
    lower_ms: int
    upper_ms: int
    lower_closed: bool = True
    upper_closed: bool = True


@dataclass(frozen=True)
class AtomicProposition:
    name: str
    kind: str
    phase: str
    predicate: str
    correlation_key: str
    required_entities: List[str]
    function_hints: List[str]


@dataclass(frozen=True)
class PropertyIR:
    schema_version: str
    property_id: str
    pattern: str
    semantics: str
    formula: str
    interval: TimeInterval
    propositions: Dict[str, AtomicProposition]
    provenance: Dict[str, str]

    def validate(self) -> None:
        if self.schema_version != "tafuzz-property-ir/0.1":
            raise ValueError("unsupported property IR schema")
        if self.pattern != "bounded_response":
            raise ValueError("prototype only accepts bounded_response")
        if self.semantics != "point_event":
            raise ValueError("prototype only accepts point_event semantics")
        if self.interval.lower_ms < 0 or self.interval.upper_ms < self.interval.lower_ms:
            raise ValueError("invalid non-negative MITL interval")
        if not self.provenance.get("rfc") or not self.provenance.get("section"):
            raise ValueError("property provenance is incomplete")
        if not self.provenance.get("quote"):
            raise ValueError("property must retain its source quote")
        if set(self.propositions) != {"con_sent", "ack_received"}:
            raise ValueError("prototype requires con_sent and ack_received")
        for name, proposition in self.propositions.items():
            if proposition.name != name:
                raise ValueError("proposition key/name mismatch")
            if proposition.kind != "event":
                raise ValueError("prototype propositions must be events")
            if name not in self.formula:
                raise ValueError("formula does not reference every proposition")
            if not proposition.correlation_key:
                raise ValueError("event proposition lacks correlation key")

    def to_json(self) -> str:
        self.validate()
        return json.dumps(asdict(self), ensure_ascii=False, indent=2, sort_keys=True)

