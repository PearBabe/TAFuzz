from __future__ import annotations

import re

from .ir import AtomicProposition, PropertyIR, TimeInterval


_WITHIN = re.compile(
    r"\bwithin\s+(?P<value>\d+)\s*(?P<unit>milliseconds?|seconds?)\b",
    re.IGNORECASE,
)


def _milliseconds(value: int, unit: str) -> int:
    return value if unit.lower().startswith("millisecond") else value * 1000


def _property_id(rfc: str, section: str) -> str:
    normalized_rfc = re.sub(r"[^a-z0-9]+", "", rfc.lower())
    normalized_section = re.sub(r"[^a-z0-9]+", "_", section.lower()).strip("_")
    return f"{normalized_rfc}_s{normalized_section}_con_ack_deadline"


def extract_requirement(text: str, *, rfc: str, section: str) -> PropertyIR:
    """Extract one deliberately narrow, auditable RFC bounded-response template.

    This deterministic recognizer is a feasibility oracle for the typed IR. The
    production design uses retrieval plus an LLM candidate generator, but every
    candidate must pass the same kind of deterministic validation.
    """

    lowered = text.lower()
    match = _WITHIN.search(text)
    required_cues = (
        "confirmable" in lowered or re.search(r"\bcon\b", lowered),
        re.search(r"\back\b", lowered),
        "must" in lowered,
        match is not None,
        "matching" in lowered,
    )
    if not all(required_cues):
        raise ValueError("unsupported requirement template; refusing to guess MITL")

    assert match is not None
    upper_ms = _milliseconds(int(match.group("value")), match.group("unit"))
    prop = PropertyIR(
        schema_version="tafuzz-property-ir/0.1",
        property_id=_property_id(rfc, section),
        pattern="bounded_response",
        semantics="point_event",
        formula=f"G (con_sent -> F[0,{upper_ms}] ack_received)",
        interval=TimeInterval(lower_ms=0, upper_ms=upper_ms),
        propositions={
            "con_sent": AtomicProposition(
                name="con_sent",
                kind="event",
                phase="trigger",
                predicate="packet.type == COAP_CON",
                correlation_key="packet.mid",
                required_entities=[
                    "packet.type",
                    "packet.mid",
                    "awaiting_mid",
                    "deadline_ms",
                ],
                function_hints=["send", "transmit", "enqueue"],
            ),
            "ack_received": AtomicProposition(
                name="ack_received",
                kind="event",
                phase="response",
                predicate=(
                    "packet.type == COAP_ACK && packet.mid == awaiting_mid"
                ),
                correlation_key="packet.mid",
                required_entities=["packet.type", "packet.mid", "awaiting_mid"],
                function_hints=["receive", "parse", "dispatch"],
            ),
        },
        provenance={"rfc": rfc, "section": section, "quote": text},
    )
    prop.validate()
    return prop

