from __future__ import annotations

from dataclasses import dataclass
from typing import List

from pycparser import c_ast, c_generator, c_parser

from .dependencies import DependencyGraph
from .ir import PropertyIR


@dataclass(frozen=True)
class ObservationPoint:
    event_id: int
    proposition: str
    function: str
    condition: str
    correlation_expression: str
    placement: str


@dataclass(frozen=True)
class InstrumentationPlan:
    points: List[ObservationPoint]


def select_observation_points(
    graph: DependencyGraph, prop: PropertyIR
) -> InstrumentationPlan:
    prop.validate()
    points: List[ObservationPoint] = []
    for event_id, proposition in enumerate(prop.propositions, start=1):
        anchor = graph.anchors.get(proposition)
        if anchor is None:
            raise ValueError(f"missing event anchor for {proposition}")
        points.append(
            ObservationPoint(
                event_id=event_id,
                proposition=proposition,
                function=str(anchor["function"]),
                condition=str(anchor["condition"]),
                correlation_expression="packet->mid",
                placement=(
                    "after_state_updates"
                    if prop.propositions[proposition].phase == "trigger"
                    else "before_state_mutation"
                ),
            )
        )
    return InstrumentationPlan(points=points)


def _emit_call(point: ObservationPoint) -> c_ast.FuncCall:
    return c_ast.FuncCall(
        name=c_ast.ID("tafuzz_emit"),
        args=c_ast.ExprList(
            [
                c_ast.Constant("int", str(point.event_id)),
                c_ast.StructRef(c_ast.ID("packet"), "->", c_ast.ID("mid")),
            ]
        ),
    )


def instrument_source(source: str, plan: InstrumentationPlan) -> str:
    parser = c_parser.CParser()
    generator = c_generator.CGenerator()
    ast = parser.parse(source)
    points_by_function = {point.function: point for point in plan.points}
    inserted = set()

    class Injector(c_ast.NodeVisitor):
        def __init__(self):
            self.function = None

        def visit_FuncDef(self, node: c_ast.FuncDef) -> None:
            previous = self.function
            self.function = node.decl.name
            self.visit(node.body)
            self.function = previous

        def visit_If(self, node: c_ast.If) -> None:
            point = points_by_function.get(self.function)
            if point and point.proposition not in inserted:
                condition = generator.visit(node.cond)
                marker = "COAP_CON" if point.proposition == "con_sent" else "COAP_ACK"
                if marker in condition:
                    if not isinstance(node.iftrue, c_ast.Compound):
                        node.iftrue = c_ast.Compound([node.iftrue])
                    items = list(node.iftrue.block_items or [])
                    if point.placement == "after_state_updates":
                        node.iftrue.block_items = [*items, _emit_call(point)]
                    else:
                        node.iftrue.block_items = [_emit_call(point), *items]
                    inserted.add(point.proposition)
            self.generic_visit(node)

    Injector().visit(ast)
    missing = {point.proposition for point in plan.points} - inserted
    if missing:
        raise ValueError(f"failed to instrument propositions: {sorted(missing)}")

    declaration = parser.parse(
        "void tafuzz_emit(unsigned event_id, unsigned correlation);"
    ).ext[0]
    ast.ext.insert(0, declaration)
    return generator.visit(ast) + "\n"


def render_runtime_support(plan: InstrumentationPlan) -> str:
    cases = "\n".join(
        f'        case {point.event_id}: name = "{point.proposition}"; break;'
        for point in plan.points
    )
    return f'''#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TAFUZZ_BUFFER_CAPACITY 4096u

struct tafuzz_record {{
    long long time_ms;
    unsigned event_id;
    unsigned correlation;
}};

static struct tafuzz_record tafuzz_records[TAFUZZ_BUFFER_CAPACITY];
static unsigned tafuzz_record_count = 0;
static unsigned tafuzz_dropped_count = 0;
static long long tafuzz_origin_ms = 0;
static int tafuzz_registered = 0;

static const char *tafuzz_event_name(unsigned event_id) {{
    const char *name = "unknown_event";
    switch (event_id) {{
{cases}
        default: break;
    }}
    return name;
}}

static void tafuzz_flush(void) {{
    unsigned index;
    puts("time,props");
    for (index = 0; index < tafuzz_record_count; ++index) {{
        const struct tafuzz_record *record = &tafuzz_records[index];
        printf("%lld,%s\\n", record->time_ms - tafuzz_origin_ms,
               tafuzz_event_name(record->event_id));
    }}
    if (tafuzz_dropped_count != 0) {{
        printf("# dropped_events=%u\\n", tafuzz_dropped_count);
    }}
    fflush(stdout);
}}

void tafuzz_emit(unsigned event_id, unsigned correlation) {{
    struct timespec now;
    long long current_ms;
    if (!tafuzz_registered) {{
        tafuzz_registered = 1;
        if (atexit(tafuzz_flush) != 0) {{
            return;
        }}
    }}
    if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) {{
        return;
    }}
    current_ms = (long long)now.tv_sec * 1000LL + now.tv_nsec / 1000000LL;
    if (tafuzz_record_count == 0) {{
        tafuzz_origin_ms = current_ms;
    }}
    if (tafuzz_record_count >= TAFUZZ_BUFFER_CAPACITY) {{
        ++tafuzz_dropped_count;
        return;
    }}
    tafuzz_records[tafuzz_record_count].time_ms = current_ms;
    tafuzz_records[tafuzz_record_count].event_id = event_id;
    tafuzz_records[tafuzz_record_count].correlation = correlation;
    ++tafuzz_record_count;
}}
'''
