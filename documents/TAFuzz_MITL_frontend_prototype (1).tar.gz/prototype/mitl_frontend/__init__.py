"""Feasibility prototype for the TAFuzz MITL front-end pipeline."""

