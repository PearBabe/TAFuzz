from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Set, Tuple

from pycparser import c_ast, c_generator, c_parser

from .ir import PropertyIR


@dataclass(frozen=True)
class DependencyEdge:
    source: str
    target: str
    kind: str


@dataclass
class DependencyGraph:
    nodes: Set[str] = field(default_factory=set)
    edges: List[DependencyEdge] = field(default_factory=list)
    anchors: Dict[str, Dict[str, object]] = field(default_factory=dict)

    def add_edge(self, source: str, target: str, kind: str) -> None:
        self.nodes.update((source, target))
        edge = DependencyEdge(source, target, kind)
        if edge not in self.edges:
            self.edges.append(edge)

    def has_path(self, source: str, target: str) -> bool:
        outgoing: Dict[str, List[str]] = {}
        for edge in self.edges:
            outgoing.setdefault(edge.source, []).append(edge.target)
        pending = [source]
        visited: Set[str] = set()
        while pending:
            current = pending.pop()
            if current == target:
                return True
            if current in visited:
                continue
            visited.add(current)
            pending.extend(outgoing.get(current, []))
        return False


def _struct_ref(node: c_ast.StructRef) -> str:
    base = node.name.name if isinstance(node.name, c_ast.ID) else "object"
    field_name = node.field.name if isinstance(node.field, c_ast.ID) else "field"
    if base in {"packet", "p", "msg", "message"}:
        base = "packet"
    return f"field:{base}.{field_name}"


def _id_ref(name: str) -> str:
    if name == "deadline_ms" or "timer" in name or "timeout" in name:
        return f"timer:{name}"
    if name in {"awaiting_mid", "session_state", "retransmit_count"}:
        return f"state:{name}"
    return f"var:{name}"


def _array_ref(node: c_ast.ArrayRef, generator: c_generator.CGenerator) -> str:
    return f"input:{generator.visit(node)}"


def _refs(node: Optional[c_ast.Node], generator: c_generator.CGenerator) -> Set[str]:
    if node is None:
        return set()
    if isinstance(node, c_ast.ArrayRef):
        return {_array_ref(node, generator)}
    if isinstance(node, c_ast.StructRef):
        return {_struct_ref(node)}
    if isinstance(node, c_ast.ID):
        if node.name.startswith("COAP_"):
            return set()
        return {_id_ref(node.name)}
    refs: Set[str] = set()
    for _, child in node.children():
        refs.update(_refs(child, generator))
    return refs


def _target(node: c_ast.Node, generator: c_generator.CGenerator) -> str:
    if isinstance(node, c_ast.StructRef):
        return _struct_ref(node)
    if isinstance(node, c_ast.ID):
        return _id_ref(node.name)
    return f"var:{generator.visit(node)}"


class _Analyzer(c_ast.NodeVisitor):
    def __init__(self, prop: PropertyIR):
        self.prop = prop
        self.graph = DependencyGraph()
        self.generator = c_generator.CGenerator()
        self.current_function: Optional[str] = None
        self.control_refs: List[Set[str]] = []

    def visit_FuncDef(self, node: c_ast.FuncDef) -> None:
        previous = self.current_function
        self.current_function = node.decl.name
        self.graph.nodes.add(f"function:{node.decl.name}")
        self.visit(node.body)
        self.current_function = previous

    def visit_Assignment(self, node: c_ast.Assignment) -> None:
        target = _target(node.lvalue, self.generator)
        sources = _refs(node.rvalue, self.generator)
        for source in sources:
            self.graph.add_edge(source, target, "data")
        for controls in self.control_refs:
            for source in controls:
                self.graph.add_edge(source, target, "control")
        if self.current_function:
            self.graph.add_edge(f"function:{self.current_function}", target, "contains")
        self.generic_visit(node)

    def visit_If(self, node: c_ast.If) -> None:
        condition = self.generator.visit(node.cond)
        condition_refs = _refs(node.cond, self.generator)
        proposition = None
        if "COAP_CON" in condition:
            proposition = "con_sent"
        elif "COAP_ACK" in condition:
            proposition = "ack_received"

        self.control_refs.append(condition_refs)
        if proposition and self.current_function:
            ap = f"ap:{proposition}"
            for source in condition_refs:
                self.graph.add_edge(source, ap, "predicate")
            self.graph.add_edge(
                f"function:{self.current_function}", ap, "event_anchor"
            )
            self.graph.anchors[proposition] = {
                "function": self.current_function,
                "condition": condition,
                "line": node.coord.line if node.coord else None,
            }
        self.visit(node.iftrue)
        self.control_refs.pop()

        if proposition:
            ap = f"ap:{proposition}"
            for written in _assigned_targets(node.iftrue, self.generator):
                self.graph.add_edge(written, ap, "state_at_event")

        if node.iffalse is not None:
            self.control_refs.append(condition_refs)
            self.visit(node.iffalse)
            self.control_refs.pop()


def _assigned_targets(
    node: c_ast.Node, generator: c_generator.CGenerator
) -> Iterable[str]:
    targets: List[str] = []

    class Collector(c_ast.NodeVisitor):
        def visit_Assignment(self, assignment: c_ast.Assignment) -> None:
            targets.append(_target(assignment.lvalue, generator))
            self.generic_visit(assignment)

    Collector().visit(node)
    return targets


def analyze_source(source: str, prop: PropertyIR, *, filename: str) -> DependencyGraph:
    del filename
    prop.validate()
    parser = c_parser.CParser()
    try:
        ast = parser.parse(source)
    except Exception as error:
        raise ValueError(f"C source could not be parsed: {error}") from error
    analyzer = _Analyzer(prop)
    analyzer.visit(ast)
    missing = set(prop.propositions) - set(analyzer.graph.anchors)
    if missing:
        raise ValueError(f"no source anchor found for propositions: {sorted(missing)}")
    return analyzer.graph

