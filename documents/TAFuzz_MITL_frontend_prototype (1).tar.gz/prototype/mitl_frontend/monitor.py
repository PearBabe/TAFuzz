from __future__ import annotations

from dataclasses import dataclass
from typing import List, Set


@dataclass(frozen=True)
class TraceEvent:
    time_ms: int
    props: Set[str]


def parse_tamonitor_trace(text: str) -> List[TraceEvent]:
    events: List[TraceEvent] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or line.lower() == "time,props":
            continue
        try:
            time_text, props_text = line.split(",", 1)
            time_ms = int(time_text.strip())
        except (ValueError, TypeError) as error:
            raise ValueError(f"invalid TAMonitor trace line: {line}") from error
        props = {
            item
            for item in props_text.replace("{", "").replace("}", "").split()
            if item
        }
        events.append(TraceEvent(time_ms=time_ms, props=props))
    if any(events[index].time_ms > events[index + 1].time_ms for index in range(len(events) - 1)):
        raise ValueError("trace timestamps must be monotonic")
    return events


def evaluate_bounded_response(
    trace: List[TraceEvent],
    *,
    trigger: str,
    response: str,
    upper_bound_ms: int,
    completed_at_ms: int,
) -> str:
    pending: List[int] = []
    for event in trace:
        if trigger in event.props:
            pending.append(event.time_ms)
        if response in event.props:
            for index, start in enumerate(pending):
                if 0 <= event.time_ms - start <= upper_bound_ms:
                    pending.pop(index)
                    break
        if any(event.time_ms - start > upper_bound_ms for start in pending):
            return "NEGATIVE"
    if any(completed_at_ms - start > upper_bound_ms for start in pending):
        return "NEGATIVE"
    return "INCONCLUSIVE" if pending else "POSITIVE"

