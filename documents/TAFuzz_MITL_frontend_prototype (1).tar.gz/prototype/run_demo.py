#!/usr/bin/env python3
from pathlib import Path

from mitl_frontend.pipeline import run_demo


ROOT = Path(__file__).resolve().parent
REQUIREMENT = (
    "When a confirmable CoAP message is sent, the sender MUST receive "
    "a matching ACK within 5 seconds."
)


def main() -> int:
    result = run_demo(
        requirement=REQUIREMENT,
        source_path=ROOT / "tests" / "fixtures" / "coap_demo.c",
        output_dir=ROOT / "out",
        rfc="RFC7252",
        section="4.2",
    )
    print(f"verdict={result.verdict}")
    for artifact in result.artifacts:
        print(artifact)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

