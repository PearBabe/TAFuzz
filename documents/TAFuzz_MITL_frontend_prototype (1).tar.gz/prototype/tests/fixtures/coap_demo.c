typedef unsigned char u8;
typedef unsigned long u64;

enum {
    COAP_CON = 0,
    COAP_ACK = 2
};

typedef struct {
    unsigned type;
    unsigned mid;
} coap_packet_t;

static int awaiting_mid = -1;
static u64 deadline_ms = 0;

static u64 now_ms(void) {
    return 100;
}

static void parse_packet(const u8 *buf, coap_packet_t *packet) {
    packet->type = (buf[0] >> 6) & 3;
    packet->mid = ((unsigned)buf[2] << 8) | buf[3];
}

static void send_packet(coap_packet_t *packet) {
    if (packet->type == COAP_CON) {
        awaiting_mid = (int)packet->mid;
        deadline_ms = now_ms() + 5000;
    }
}

static int receive_packet(coap_packet_t *packet) {
    if (packet->type == COAP_ACK && packet->mid == (unsigned)awaiting_mid) {
        awaiting_mid = -1;
        return 1;
    }
    return 0;
}

int main(void) {
    const u8 con_bytes[4] = {0x00, 0x01, 0x00, 0x2a};
    const u8 ack_bytes[4] = {0x80, 0x00, 0x00, 0x2a};
    coap_packet_t packet;

    parse_packet(con_bytes, &packet);
    send_packet(&packet);
    parse_packet(ack_bytes, &packet);
    return receive_packet(&packet) ? 0 : 1;
}
