import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import call, patch


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mitl_frontend.dependencies import analyze_source
from mitl_frontend.extractor import extract_requirement
from mitl_frontend.instrumentation import (
    instrument_source,
    render_runtime_support,
    select_observation_points,
)
from mitl_frontend.monitor import evaluate_bounded_response, parse_tamonitor_trace
from mitl_frontend.pipeline import _find_clang, run_demo


FIXTURE = ROOT / "tests" / "fixtures" / "coap_demo.c"
REQUIREMENT = (
    "When a confirmable CoAP message is sent, the sender MUST receive "
    "a matching ACK within 5 seconds."
)


class PropertyExtractionTests(unittest.TestCase):
    def test_extracts_typed_bounded_response_property(self):
        prop = extract_requirement(REQUIREMENT, rfc="RFC7252", section="4.2")

        self.assertEqual(prop.property_id, "rfc7252_s4_2_con_ack_deadline")
        self.assertEqual(prop.formula, "G (con_sent -> F[0,5000] ack_received)")
        self.assertEqual(prop.interval.lower_ms, 0)
        self.assertEqual(prop.interval.upper_ms, 5000)
        self.assertEqual(prop.semantics, "point_event")
        self.assertEqual(set(prop.propositions), {"con_sent", "ack_received"})
        self.assertEqual(prop.propositions["ack_received"].correlation_key, "packet.mid")
        prop.validate()

        as_json = json.loads(prop.to_json())
        self.assertEqual(as_json["provenance"]["rfc"], "RFC7252")
        self.assertEqual(as_json["provenance"]["section"], "4.2")
        self.assertEqual(as_json["provenance"]["quote"], REQUIREMENT)

    def test_rejects_unsupported_requirement_instead_of_guessing(self):
        with self.assertRaisesRegex(ValueError, "unsupported requirement template"):
            extract_requirement(
                "Endpoints SHOULD behave correctly under normal conditions.",
                rfc="RFC7252",
                section="0",
            )


class DependencyAndInstrumentationTests(unittest.TestCase):
    def setUp(self):
        self.source = FIXTURE.read_text(encoding="utf-8")
        self.prop = extract_requirement(REQUIREMENT, rfc="RFC7252", section="4.2")

    def test_recovers_input_field_state_timer_and_event_dependencies(self):
        graph = analyze_source(self.source, self.prop, filename=str(FIXTURE))

        self.assertTrue(graph.has_path("input:buf[0]", "ap:ack_received"))
        self.assertTrue(graph.has_path("input:buf[2]", "ap:ack_received"))
        self.assertTrue(graph.has_path("input:buf[3]", "ap:ack_received"))
        self.assertTrue(graph.has_path("field:packet.mid", "state:awaiting_mid"))
        self.assertTrue(graph.has_path("field:packet.mid", "ap:con_sent"))
        self.assertTrue(graph.has_path("timer:deadline_ms", "ap:con_sent"))
        self.assertIn("function:receive_packet", graph.nodes)

    def test_selects_only_two_property_relevant_observation_points(self):
        graph = analyze_source(self.source, self.prop, filename=str(FIXTURE))
        plan = select_observation_points(graph, self.prop)

        self.assertEqual(len(plan.points), 2)
        self.assertEqual(
            {(p.proposition, p.function) for p in plan.points},
            {("con_sent", "send_packet"), ("ack_received", "receive_packet")},
        )
        self.assertEqual([p.event_id for p in plan.points], [1, 2])

    def test_instrumented_program_compiles_and_emits_tamonitor_trace(self):
        graph = analyze_source(self.source, self.prop, filename=str(FIXTURE))
        plan = select_observation_points(graph, self.prop)
        instrumented = instrument_source(self.source, plan)

        self.assertEqual(instrumented.count("tafuzz_emit("), 3)
        self.assertIn("tafuzz_emit(1, packet->mid);", instrumented)
        self.assertIn("tafuzz_emit(2, packet->mid);", instrumented)
        self.assertLess(
            instrumented.index("deadline_ms = now_ms() + 5000"),
            instrumented.index("tafuzz_emit(1, packet->mid);"),
            "con_sent must be observed after its correlated state/timer updates",
        )
        self.assertLess(
            instrumented.index("tafuzz_emit(2, packet->mid);"),
            instrumented.index("awaiting_mid = -1", instrumented.index("receive_packet")),
            "ack_received must be observed before the matching state is cleared",
        )

        runtime_support = render_runtime_support(plan)
        self.assertIn("TAFUZZ_BUFFER_CAPACITY", runtime_support)
        self.assertIn("atexit(tafuzz_flush)", runtime_support)

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            source_path = tmp_path / "coap_instrumented.c"
            runtime_path = tmp_path / "tafuzz_runtime.c"
            binary_path = tmp_path / "coap_demo"
            source_path.write_text(instrumented, encoding="utf-8")
            runtime_path.write_text(runtime_support, encoding="utf-8")

            compile_result = subprocess.run(
                [
                    _find_clang(),
                    "-std=c11",
                    "-Wall",
                    "-Wextra",
                    "-Werror",
                    str(source_path),
                    str(runtime_path),
                    "-o",
                    str(binary_path),
                ],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(compile_result.returncode, 0, compile_result.stderr)

            run_result = subprocess.run(
                [str(binary_path)], capture_output=True, text=True, check=False
            )
            self.assertEqual(run_result.returncode, 0, run_result.stderr)
            trace = parse_tamonitor_trace(run_result.stdout)
            self.assertEqual([e.props for e in trace], [{"con_sent"}, {"ack_received"}])
            self.assertLessEqual(trace[0].time_ms, trace[1].time_ms)
            self.assertEqual(
                evaluate_bounded_response(
                    trace,
                    trigger="con_sent",
                    response="ack_received",
                    upper_bound_ms=5000,
                    completed_at_ms=trace[-1].time_ms,
                ),
                "POSITIVE",
            )


class RuntimeSemanticsTests(unittest.TestCase):
    def test_missing_ack_becomes_negative_only_after_deadline(self):
        trace = parse_tamonitor_trace("time,props\n0,con_sent\n")
        self.assertEqual(
            evaluate_bounded_response(
                trace,
                trigger="con_sent",
                response="ack_received",
                upper_bound_ms=5000,
                completed_at_ms=1000,
            ),
            "INCONCLUSIVE",
        )
        self.assertEqual(
            evaluate_bounded_response(
                trace,
                trigger="con_sent",
                response="ack_received",
                upper_bound_ms=5000,
                completed_at_ms=5001,
            ),
            "NEGATIVE",
        )


class ReproducibleDemoTests(unittest.TestCase):
    def test_pipeline_selects_clang_without_gcc_fallback(self):
        def find_compiler(name):
            return {
                "clang-18": "/opt/llvm/bin/clang-18",
                "gcc": "/usr/bin/gcc",
            }.get(name)

        compile_result = subprocess.CompletedProcess([], 0, "", "")
        run_result = subprocess.CompletedProcess(
            [], 0, "time,props\n0,con_sent\n1,ack_received\n", ""
        )

        with tempfile.TemporaryDirectory() as tmp:
            with patch(
                "mitl_frontend.pipeline.shutil.which", side_effect=find_compiler
            ) as which:
                with patch(
                    "mitl_frontend.pipeline.subprocess.run",
                    side_effect=[compile_result, run_result],
                ) as run:
                    run_demo(
                        requirement=REQUIREMENT,
                        source_path=FIXTURE,
                        output_dir=Path(tmp),
                        rfc="RFC7252",
                        section="4.2",
                    )

        compile_command = run.call_args_list[0].args[0]
        self.assertEqual(compile_command[0], "/opt/llvm/bin/clang-18")
        which.assert_any_call("clang-18")
        self.assertNotIn(call("gcc"), which.mock_calls)

    def test_one_command_pipeline_writes_auditable_artifacts(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = run_demo(
                requirement=REQUIREMENT,
                source_path=FIXTURE,
                output_dir=Path(tmp),
                rfc="RFC7252",
                section="4.2",
            )

            expected = {
                "property_ir.json",
                "dependency_graph.json",
                "instrumentation_plan.json",
                "coap_instrumented.c",
                "tafuzz_runtime.c",
                "trace.csv",
                "verdict.txt",
            }
            self.assertEqual({path.name for path in result.artifacts}, expected)
            self.assertEqual(result.verdict, "POSITIVE")
            self.assertEqual((Path(tmp) / "verdict.txt").read_text().strip(), "POSITIVE")
            graph = json.loads((Path(tmp) / "dependency_graph.json").read_text())
            self.assertIn("ap:ack_received", graph["nodes"])
            self.assertTrue(
                any(
                    edge["source"] == "input:buf[0]"
                    and edge["target"] == "field:packet.type"
                    for edge in graph["edges"]
                )
            )


if __name__ == "__main__":
    unittest.main()
